import React, { useEffect, useRef, useState, useMemo } from 'react';
import { EngineResponse } from '../types';
import { Terminal, Cpu, Activity, Copy, Check, ExternalLink, Hash, Loader2 } from 'lucide-react';

interface ConsoleProps {
  history: EngineResponse[];
  isProcessing: boolean;
}

const CopyButton: React.FC<{ text: string }> = ({ text }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button 
      onClick={handleCopy} 
      className="p-1.5 text-neutral-500 hover:text-emerald-500 transition-colors rounded-md hover:bg-white/5"
      title="Copy to clipboard"
    >
      {copied ? <Check size={14} /> : <Copy size={14} />}
    </button>
  );
};

const FormattedContent: React.FC<{ text: string }> = ({ text }) => {
  // Enhanced splitting logic to handle incomplete/streaming code blocks
  const parts = useMemo(() => {
    const segments = [];
    // Regex for completed code blocks
    const splitRegex = /(```[\s\S]*?```)/g;
    let lastIndex = 0;
    let match;

    while ((match = splitRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        segments.push({ type: 'text', content: text.slice(lastIndex, match.index) });
      }
      segments.push({ type: 'code', content: match[0] });
      lastIndex = splitRegex.lastIndex;
    }

    const remaining = text.slice(lastIndex);
    // Check if remaining text starts with an unclosed code block
    if (remaining.trimStart().startsWith('```')) {
       segments.push({ type: 'code', content: remaining, isUnclosed: true });
    } else if (remaining) {
       segments.push({ type: 'text', content: remaining });
    }
    return segments;
  }, [text]);

  return (
    <div className="space-y-4">
      {parts.map((part, index) => {
        if (part.type === 'code') {
          // Parse language and content
          let content = part.content;
          let lang = '';
          
          if (part.isUnclosed) {
              const lines = content.split('\n');
              const firstLine = lines[0];
              const langMatch = firstLine.match(/^```(\w+)/);
              lang = langMatch ? langMatch[1] : '';
              // For unclosed blocks, we just strip the first line (```lang)
              content = lines.slice(1).join('\n');
          } else {
              // Standard stripping for closed blocks
              content = part.content.replace(/^```\w*\n?|```$/g, '');
              const langMatch = part.content.match(/^```(\w+)/);
              lang = langMatch ? langMatch[1] : '';
          }
          
          return (
            <div key={index} className="relative group my-4 rounded-lg overflow-hidden border border-white/5 bg-black/40 shadow-inner">
              <div className="flex items-center justify-between px-3 py-1.5 bg-black/40 border-b border-white/5">
                <span className="text-xs font-mono text-neutral-500">{lang || 'code'}</span>
                {/* Only show copy button if content exists */}
                {content && <CopyButton text={content} />}
              </div>
              <pre className="p-4 overflow-x-auto text-sm font-mono text-emerald-100/90 leading-relaxed custom-scrollbar">
                <code>{content}</code>
                {part.isUnclosed && <span className="inline-block w-2 h-4 bg-emerald-500/50 ml-1 animate-pulse align-middle"></span>}
              </pre>
            </div>
          );
        }

        // Regular Markdown Processing
        return part.content.split('\n\n').map((para, pIndex) => {
          if (!para.trim()) return null;

          if (para.startsWith('# ')) {
            return <h1 key={`${index}-${pIndex}`} className="text-2xl font-cinzel font-bold text-white mt-8 mb-4 border-b border-white/10 pb-2 drop-shadow-[0_0_10px_rgba(255,255,255,0.1)]">{para.replace('# ', '')}</h1>;
          }
          if (para.startsWith('## ')) {
            return <h2 key={`${index}-${pIndex}`} className="text-xl font-cinzel text-neutral-200 mt-6 mb-3 flex items-center gap-2"><Hash size={16} className="text-neutral-600"/>{para.replace('## ', '')}</h2>;
          }
          if (para.startsWith('### ')) {
            return <h3 key={`${index}-${pIndex}`} className="text-lg font-bold text-neutral-300 mt-4 mb-2">{para.replace('### ', '')}</h3>;
          }

          if (para.match(/^[-*] /m)) {
            const items = para.split('\n').filter(l => l.trim().match(/^[-*] /));
            return (
              <ul key={`${index}-${pIndex}`} className="list-disc list-inside text-neutral-400 ml-4 my-2 space-y-1">
                {items.map((item, i) => {
                  const content = item.replace(/^[-*] /, '');
                  const parts = content.split(/(\*\*.*?\*\*)/g);
                  return (
                    <li key={i} className="font-mono text-sm leading-relaxed">
                      {parts.map((pt, k) => {
                         if (pt.startsWith('**') && pt.endsWith('**')) return <strong key={k} className="text-neutral-200 font-bold">{pt.slice(2, -2)}</strong>;
                         return pt;
                      })}
                    </li>
                  );
                })}
              </ul>
            );
          }

          // Inline formatting
          const renderInline = (str: string) => {
             const elements: React.ReactNode[] = [];
             let remaining = str;
             const parts = remaining.split(/(\[.*?\]\(.*?\)|`.*?`|\*\*.*?\*\*)/g);
             
             parts.forEach((pt, k) => {
                if (pt.startsWith('[') && pt.includes('](') && pt.endsWith(')')) {
                    const match = pt.match(/\[(.*?)\]\((.*?)\)/);
                    if (match) {
                        elements.push(
                            <a key={k} href={match[2]} target="_blank" rel="noopener noreferrer" className="text-emerald-400 hover:text-emerald-300 hover:underline inline-flex items-center gap-0.5">
                                {match[1]} <ExternalLink size={10} />
                            </a>
                        );
                        return;
                    }
                }
                if (pt.startsWith('`') && pt.endsWith('`')) {
                    elements.push(<code key={k} className="bg-white/10 text-neutral-200 px-1 py-0.5 rounded text-xs font-mono">{pt.slice(1, -1)}</code>);
                    return;
                }
                if (pt.startsWith('**') && pt.endsWith('**')) {
                    elements.push(<strong key={k} className="text-neutral-200">{pt.slice(2, -2)}</strong>);
                    return;
                }
                elements.push(pt);
             });

             return elements;
          };

          return <p key={`${index}-${pIndex}`} className="text-neutral-300 leading-relaxed mb-4 font-mono text-sm">{renderInline(para)}</p>;
        });
      })}
    </div>
  );
};

const Typewriter: React.FC<{ text: string, onComplete?: () => void }> = ({ text, onComplete }) => {
  const [displayedText, setDisplayedText] = useState('');
  const indexRef = useRef(0);
  const speed = 5; 

  useEffect(() => {
    if (text.length < displayedText.length) {
       setDisplayedText('');
       indexRef.current = 0;
    }
  }, [text]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (indexRef.current < text.length) {
        const chunk = Math.max(1, Math.floor((text.length - indexRef.current) / 50)) + 1;
        setDisplayedText(prev => prev + text.slice(indexRef.current, indexRef.current + chunk));
        indexRef.current += chunk;
      } else {
        clearInterval(interval);
        if (onComplete) onComplete();
      }
    }, speed);

    return () => clearInterval(interval);
  }, [text, speed, onComplete]);

  return <FormattedContent text={displayedText} />;
};

export const Console: React.FC<ConsoleProps> = ({ history, isProcessing }) => {
  const bottomRef = useRef<HTMLDivElement>(null);
  const [animatedIds, setAnimatedIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history, isProcessing, animatedIds]);

  const handleAnimationComplete = (id: string) => {
    setAnimatedIds(prev => new Set(prev).add(id));
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-10 min-h-0 custom-scrollbar">
      {history.length === 0 && (
        <div className="h-full flex flex-col items-center justify-center text-neutral-500 opacity-60 space-y-6">
          <div className="relative">
            <Cpu size={64} strokeWidth={1} className="text-emerald-500/50" />
            <div className="absolute inset-0 bg-emerald-500/20 blur-xl rounded-full"></div>
          </div>
          <div className="text-center font-cinzel">
            <p className="text-2xl tracking-widest text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.3)]">CODEX ENGINE vΩX.Φ</p>
            <p className="text-xs font-mono mt-3 text-neutral-400">Awaiting Ontological Input...</p>
          </div>
        </div>
      )}

      {history.map((entry, idx) => {
        const isLatest = idx === history.length - 1;
        const needsAnimation = isLatest && !animatedIds.has(entry.id) && entry.status === 'complete';
        
        return (
          <div key={entry.id} className="space-y-4 pl-4 border-l border-white/5 animate-in fade-in duration-500 group">
            {/* User Query Block */}
            <div className="flex items-center justify-between text-xs uppercase tracking-widest text-neutral-500">
              <div className="flex items-center gap-2">
                <Terminal size={12} className="text-emerald-500" />
                <span>Input Vector [{new Date(entry.timestamp).toLocaleTimeString()}]</span>
              </div>
              <CopyButton text={entry.query} />
            </div>
            
            <div className="font-mono text-neutral-200 text-lg italic neu-inset p-5 rounded-lg border-l-4 border-emerald-500/50 backdrop-blur-sm">
              "{entry.query}"
            </div>

            {/* System Response Block */}
            <div className="flex items-center justify-between text-xs uppercase tracking-widest text-neutral-500 mt-8">
              <div className="flex items-center gap-2">
                <Activity size={12} className="text-purple-500" />
                <span>Codex Output</span>
              </div>
              <div className="flex gap-2">
                 <CopyButton text={entry.content} />
              </div>
            </div>
            
            <div className="glass-card p-6 rounded-xl shadow-2xl relative overflow-hidden">
                {/* Decorative sheen */}
                <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/5 blur-[100px] rounded-full pointer-events-none"></div>
                <div className="relative z-10 prose prose-invert max-w-none prose-p:text-neutral-300">
                  {needsAnimation ? (
                      <Typewriter text={entry.content} onComplete={() => handleAnimationComplete(entry.id)} />
                  ) : (
                      <FormattedContent text={entry.content} />
                  )}
                </div>
            </div>
            
            {entry.metaReflection && (
              <div className={`mt-4 p-4 glass-card border-red-500/20 bg-red-950/10 text-xs font-mono text-red-200/80 rounded-lg shadow-lg ${needsAnimation ? 'animate-in fade-in duration-1000 delay-1000 fill-mode-forwards opacity-0' : ''}`} style={{ animationDelay: '2s' }}>
                <div className="flex items-center gap-2 mb-2 text-red-400">
                    <Activity size={12} /> 
                    <span className="uppercase font-bold tracking-wider">Meta-Reflection Protocol</span>
                </div>
                {entry.metaReflection}
              </div>
            )}
          </div>
        );
      })}

      {isProcessing && (
        <div className="flex items-center gap-3 text-emerald-500 font-mono text-sm ml-6">
          <Loader2 size={16} className="animate-spin" />
          <span className="animate-pulse tracking-wide">Densifying thought structure...</span>
        </div>
      )}
      
      <div ref={bottomRef} />
    </div>
  );
};