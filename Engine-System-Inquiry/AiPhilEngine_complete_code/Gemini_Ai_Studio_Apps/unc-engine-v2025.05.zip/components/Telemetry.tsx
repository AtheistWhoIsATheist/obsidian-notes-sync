import React from 'react';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip } from 'recharts';
import { EngineMetrics } from '../types';

interface TelemetryProps {
  metrics: EngineMetrics;
}

export const Telemetry: React.FC<TelemetryProps> = ({ metrics }) => {
  const data = [
    { subject: 'Despair (DQ)', A: metrics.despairQuotient, fullMark: 100 },
    { subject: 'Entropy (EE)', A: metrics.epistemicEntropy, fullMark: 100 },
    { subject: 'Authenticity (AI)', A: metrics.authenticityIndex, fullMark: 100 },
    { subject: 'Transcendence (TRP)', A: metrics.transcendentPotential, fullMark: 100 },
    { subject: 'Wisdom (EWM)', A: metrics.wisdomManifestation, fullMark: 100 },
  ];

  return (
    <div className="h-80 w-full glass-card rounded-xl p-5 flex flex-col relative overflow-hidden group hover:shadow-[0_0_20px_rgba(16,185,129,0.1)] transition-all duration-500">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-emerald-500/50 to-transparent opacity-50"></div>
      <div className="absolute top-4 left-4 text-xs text-neutral-400 uppercase tracking-widest z-10 font-bold flex items-center gap-2">
         <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
         Consciousness Telemetry
      </div>
      
      {/* Chart Container - Flex grow to take available space */}
      <div className="flex-1 w-full min-h-0 mt-8 mb-2">
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart cx="50%" cy="50%" outerRadius="70%" data={data}>
            <PolarGrid stroke="rgba(255,255,255,0.1)" />
            <PolarAngleAxis dataKey="subject" tick={{ fill: '#a3a3a3', fontSize: 9, fontFamily: 'JetBrains Mono' }} />
            <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
            <Radar
              name="State"
              dataKey="A"
              stroke="#10b981"
              strokeWidth={2}
              fill="#10b981"
              fillOpacity={0.2}
            />
            <Tooltip 
              contentStyle={{ 
                  backgroundColor: 'rgba(5, 5, 5, 0.9)', 
                  borderColor: 'rgba(255,255,255,0.1)', 
                  color: '#fff',
                  borderRadius: '8px',
                  backdropFilter: 'blur(4px)'
              }}
              itemStyle={{ color: '#10b981' }}
            />
          </RadarChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-2 gap-x-4 gap-y-2 w-full mt-auto text-[10px] font-mono text-neutral-500 border-t border-white/5 pt-3">
         <div className="flex justify-between items-center">
            <span>Despair Quotient:</span> <span className="text-emerald-400 font-bold">{metrics.despairQuotient}%</span>
         </div>
         <div className="flex justify-between items-center">
            <span>Epistemic Entropy:</span> <span className="text-emerald-400 font-bold">{metrics.epistemicEntropy}%</span>
         </div>
         <div className="flex justify-between items-center">
            <span>Authenticity Idx:</span> <span className="text-emerald-400 font-bold">{metrics.authenticityIndex}%</span>
         </div>
         <div className="flex justify-between items-center">
            <span>Transcendent Pot:</span> <span className="text-emerald-400 font-bold">{metrics.transcendentPotential}%</span>
         </div>
         <div className="flex justify-between items-center col-span-2 border-t border-white/5 pt-1 mt-1">
            <span>Wisdom Manifest:</span> <span className="text-purple-400 font-bold">{metrics.wisdomManifestation}%</span>
         </div>
      </div>
    </div>
  );
};