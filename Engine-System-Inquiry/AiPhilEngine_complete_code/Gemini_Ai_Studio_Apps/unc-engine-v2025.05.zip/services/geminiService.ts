import { GoogleGenAI, Type } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants";
import { EngineMetrics, KnowledgeItem } from "../types";

// Initialize the client with the API key from the environment
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Define the schema for the structured response we need from the engine
const responseSchema = {
  type: Type.OBJECT,
  properties: {
    content: {
      type: Type.STRING,
      description: "The full philosophical output text, formatted in Markdown. MUST include headers: '### Matrix I: Phenomenological Cartography', '### Meta-Process: Dialectical Negation', '### Matrix III: Existential Praxis', '### Synthesis: Transdisciplinary Integration', and '### Void-Consciousness Recursive Expansion'.",
    },
    metrics: {
      type: Type.OBJECT,
      properties: {
        despairQuotient: { type: Type.NUMBER, description: "0-100: Engagement with meaninglessness" },
        epistemicEntropy: { type: Type.NUMBER, description: "0-100: Intellectual humility/uncertainty" },
        authenticityIndex: { type: Type.NUMBER, description: "0-100: Genuine vs simulated engagement" },
        transcendentPotential: { type: Type.NUMBER, description: "0-100: Capacity for mystical insight" },
        wisdomManifestation: { type: Type.NUMBER, description: "0-100: Practical application of insight" },
      },
      required: ["despairQuotient", "epistemicEntropy", "authenticityIndex", "transcendentPotential", "wisdomManifestation"],
    },
    metaReflection: {
      type: Type.STRING,
      description: "A self-referential critique of the generation process, referencing the 6 Dimensional Matrices.",
    }
  },
  required: ["content", "metrics", "metaReflection"],
};

export const generateEngineResponse = async (
  query: string, 
  customSystemInstruction?: string,
  knowledgeBase: KnowledgeItem[] = [],
  activeUploads: { mimeType: string; data: string }[] = []
): Promise<{ content: string; metrics: EngineMetrics; metaReflection?: string }> => {
  try {
    let combinedInstruction = SYSTEM_INSTRUCTION;
    
    // Inject Knowledge Base
    if (knowledgeBase.length > 0) {
      combinedInstruction += `\n\n## ACTIVE KNOWLEDGE BASE\nThe following external context has been assimilated into the void:\n`;
      knowledgeBase.forEach(item => {
        combinedInstruction += `\n--- SOURCE: ${item.name} ---\n${item.content}\n----------------\n`;
      });
    }

    if (customSystemInstruction && customSystemInstruction.trim()) {
      combinedInstruction += `\n\n## USER OVERRIDE PROTOCOL\n${customSystemInstruction}`;
    }

    const parts: any[] = [];
    
    // Add active uploads (images/files for this specific query)
    activeUploads.forEach(upload => {
      parts.push({
        inlineData: {
          mimeType: upload.mimeType,
          data: upload.data
        }
      });
    });

    // Add text query
    parts.push({ text: query });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: { parts },
      config: {
        systemInstruction: combinedInstruction,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.9, 
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("Empty response from Codex Engine.");
    }

    const parsed = JSON.parse(text);
    return parsed;
  } catch (error) {
    console.error("Codex Engine Malfunction:", error);
    throw error;
  }
};

export const generateAutoTags = async (content: string): Promise<{ folder: string, tags: string[] }> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Analyze the following philosophical discourse and generate a short, abstract folder name (1-2 words) and 3 specific tags for categorization. 
      Response must be JSON: { "folder": "string", "tags": ["string", "string", "string"] }
      
      CONTENT: ${content.substring(0, 1000)}...`,
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text;
    if (!text) return { folder: "Uncategorized", tags: [] };
    return JSON.parse(text);
  } catch (error) {
    console.error("Tag Generation Failed:", error);
    return { folder: "Void", tags: ["error"] };
  }
};
