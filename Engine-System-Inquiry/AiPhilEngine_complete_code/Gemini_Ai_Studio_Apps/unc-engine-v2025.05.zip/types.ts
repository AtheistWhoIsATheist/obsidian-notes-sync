export interface EngineMetrics {
  despairQuotient: number;         // DQ
  epistemicEntropy: number;        // EE
  authenticityIndex: number;       // AI (renamed from AI to avoid conflict, represents Authenticity)
  transcendentPotential: number;   // TRP
  wisdomManifestation: number;     // EWM
}

export interface EngineResponse {
  id: string;
  timestamp: number;
  query: string;
  content: string; // Markdown/Text content
  metrics: EngineMetrics;
  status: 'idle' | 'processing' | 'complete' | 'error';
  metaReflection?: string;
}

export interface ChatState {
  history: EngineResponse[];
  isProcessing: boolean;
  currentMetrics: EngineMetrics;
}

export interface KnowledgeItem {
  id: string;
  name: string;
  content: string; // Text content or base64 description
  type: 'text' | 'image' | 'code';
}

export interface SavedSession {
  id: string;
  title: string;
  tags: string[];
  folder: string;
  history: EngineResponse[];
  timestamp: number;
}
