import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Console } from './components/Console';
import { Telemetry } from './components/Telemetry';
import { generateEngineResponse, generateAutoTags } from './services/geminiService';
import { ChatState, EngineResponse, KnowledgeItem, SavedSession } from './types';
import { INITIAL_METRICS } from './constants';
import { 
  Send, RefreshCw, Zap, BookOpen, ShieldCheck, Hexagon, Layers, Activity, 
  BrainCircuit, Settings, X, Upload, FileText, Database, Plus, Save, 
  Folder, Tag, Menu, PanelLeftClose, PanelLeftOpen, Paperclip, Trash2,
  Edit2, Check, Download, Undo2, Redo2, History, Loader2
} from 'lucide-react';

const App: React.FC = () => {
  const [input, setInput] = useState('');
  const [customInstruction, setCustomInstruction] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [sidebarTab, setSidebarTab] = useState<'engine' | 'library'>('engine');
  
  // Knowledge & Files
  const [knowledgeBase, setKnowledgeBase] = useState<KnowledgeItem[]>([]);
  const [activeUploads, setActiveUploads] = useState<{name: string, mimeType: string, data: string}[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Saved Sessions
  const [savedSessions, setSavedSessions] = useState<SavedSession[]>([]);
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<{title: string, tags: string, folder: string}>({ title: '', tags: '', folder: '' });
  const [isSaving, setIsSaving] = useState(false);

  // Undo/Redo Logic
  // We maintain a stack of history arrays
  const [historyStack, setHistoryStack] = useState<EngineResponse[][]>([[]]);
  const [stackPointer, setStackPointer] = useState(0);
  
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Derived state from stack
  const currentHistory = historyStack[stackPointer] || [];
  const currentMetrics = currentHistory.length > 0 
      ? currentHistory[currentHistory.length - 1].metrics 
      : INITIAL_METRICS;

  const pushToHistory = (newHistory: EngineResponse[]) => {
      const newStack = historyStack.slice(0, stackPointer + 1);
      newStack.push(newHistory);
      setHistoryStack(newStack);
      setStackPointer(newStack.length - 1);
  };

  const handleUndo = () => {
      if (stackPointer > 0) {
          setStackPointer(stackPointer - 1);
      }
  };

  const handleRedo = () => {
      if (stackPointer < historyStack.length - 1) {
          setStackPointer(stackPointer + 1);
      }
  };

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && activeUploads.length === 0) || isProcessing) return;

    const currentInput = input;
    const currentUploads = [...activeUploads];
    
    setInput('');
    setActiveUploads([]);
    setIsProcessing(true);

    try {
      const response = await generateEngineResponse(
        currentInput, 
        customInstruction,
        knowledgeBase,
        currentUploads
      );
      
      const newEntry: EngineResponse = {
        id: Date.now().toString(),
        timestamp: Date.now(),
        query: currentInput || (currentUploads.length ? `[Uploaded ${currentUploads.length} files]` : ''),
        content: response.content,
        metrics: response.metrics,
        status: 'complete',
        metaReflection: response.metaReflection
      };

      pushToHistory([...currentHistory, newEntry]);
      setIsProcessing(false);

    } catch (error) {
      console.error(error);
       const errorEntry: EngineResponse = {
        id: Date.now().toString(),
        timestamp: Date.now(),
        query: currentInput,
        content: "### PROTOCOL FAILURE\nThe Ultimate Nihiltheistic Inquiry Protocol encountered a recursive collapse. The query could not be mapped to the void.",
        metrics: INITIAL_METRICS,
        status: 'error',
      };
      
      pushToHistory([...currentHistory, errorEntry]);
      setIsProcessing(false);
    }
  }, [input, isProcessing, customInstruction, knowledgeBase, activeUploads, currentHistory, stackPointer]);

  const handleReset = () => {
    pushToHistory([]);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          const result = event.target.result as string;
          const base64Data = result.split(',')[1];
          setActiveUploads(prev => [...prev, {
             name: file.name,
             mimeType: file.type,
             data: base64Data
          }]);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const saveToKnowledge = (uploadIndex: number) => {
     const upload = activeUploads[uploadIndex];
     try {
       const content = (upload.mimeType.startsWith('text') || upload.mimeType.includes('json') || upload.mimeType.includes('javascript')) 
           ? atob(upload.data) 
           : '[Binary Data]';
       
       if (content === '[Binary Data]') {
           alert("Only text-based files can be assimilated into the Knowledge Base currently.");
           return;
       }

       setKnowledgeBase(prev => [...prev, {
         id: Date.now().toString(),
         name: upload.name,
         content: content,
         type: 'text'
       }]);
       setActiveUploads(prev => prev.filter((_, i) => i !== uploadIndex));
     } catch (e) {
        console.error("Decoding failed", e);
     }
  };

  const handleSaveSession = async () => {
     if (currentHistory.length === 0) return;
     setIsSaving(true);
     try {
         const lastResponse = currentHistory[currentHistory.length - 1].content;
         const { folder, tags } = await generateAutoTags(lastResponse);
         const newSession: SavedSession = {
             id: Date.now().toString(),
             title: `Session ${new Date().toLocaleTimeString()}`,
             tags: tags,
             folder: folder,
             history: [...currentHistory],
             timestamp: Date.now()
         };
         setSavedSessions(prev => [newSession, ...prev]);
     } catch (e) {
         console.error("Auto-tag generation failed", e);
         // Fallback save without tags if AI fails
         const newSession: SavedSession = {
            id: Date.now().toString(),
            title: `Session ${new Date().toLocaleTimeString()}`,
            tags: ['void', 'raw'],
            folder: 'Unsorted',
            history: [...currentHistory],
            timestamp: Date.now()
        };
        setSavedSessions(prev => [newSession, ...prev]);
     } finally {
         setIsSaving(false);
     }
  };

  const restoreSession = (session: SavedSession) => {
      pushToHistory(session.history);
  };

  const startEditingSession = (session: SavedSession, e: React.MouseEvent) => {
      e.stopPropagation();
      setEditingSessionId(session.id);
      setEditForm({
          title: session.title,
          tags: session.tags.join(', '),
          folder: session.folder
      });
  };

  const saveSessionEdit = (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      setSavedSessions(prev => prev.map(s => {
          if (s.id === id) {
              return {
                  ...s,
                  title: editForm.title,
                  folder: editForm.folder,
                  tags: editForm.tags.split(',').map(t => t.trim()).filter(Boolean)
              };
          }
          return s;
      }));
      setEditingSessionId(null);
  };

  const exportSession = (session: SavedSession, e: React.MouseEvent) => {
      e.stopPropagation();
      const exportData = {
          meta: {
              title: session.title,
              date: new Date(session.timestamp).toISOString(),
              tags: session.tags,
              folder: session.folder
          },
          history: session.history.map(h => ({
              role: 'user',
              query: h.query,
              response: h.content,
              metrics: h.metrics
          }))
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `UNC_Session_${session.id}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden font-mono text-neutral-200">
      {/* Mobile Sidebar Toggle */}
      <button 
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        className="md:hidden absolute top-4 left-4 z-50 p-2 neu-btn rounded text-neutral-400"
      >
        {isSidebarOpen ? <PanelLeftClose size={20} /> : <Menu size={20} />}
      </button>

      {/* Left Panel: Glassmorphism */}
      <div className={`${isSidebarOpen ? 'w-80 translate-x-0' : 'w-0 -translate-x-full opacity-0 overflow-hidden'} transition-all duration-300 glass-panel border-r border-white/5 flex flex-col absolute md:relative z-40 h-full`}>
        <div className="p-6 border-b border-white/5 flex justify-between items-center bg-black/20">
          <h1 className="font-cinzel font-bold text-lg text-white tracking-wider flex items-center gap-2">
            <BrainCircuit size={20} className="text-emerald-500 drop-shadow-[0_0_8px_rgba(16,185,129,0.5)]" strokeWidth={1.5} />
            UNC ENGINE
          </h1>
          <button onClick={() => setIsSidebarOpen(false)} className="md:hidden text-neutral-500"><X size={18} /></button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/5">
            <button 
                onClick={() => setSidebarTab('engine')}
                className={`flex-1 py-3 text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${sidebarTab === 'engine' ? 'bg-white/5 text-white border-b-2 border-emerald-500 shadow-[0_4px_12px_rgba(16,185,129,0.1)]' : 'text-neutral-500 hover:text-neutral-300 hover:bg-white/5'}`}
            >
                <Activity size={12} /> Status
            </button>
            <button 
                onClick={() => setSidebarTab('library')}
                className={`flex-1 py-3 text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${sidebarTab === 'library' ? 'bg-white/5 text-white border-b-2 border-emerald-500 shadow-[0_4px_12px_rgba(16,185,129,0.1)]' : 'text-neutral-500 hover:text-neutral-300 hover:bg-white/5'}`}
            >
                <Database size={12} /> Library
            </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {sidebarTab === 'engine' ? (
              <div className="p-6 space-y-6">
                <section>
                    <h2 className="text-[10px] uppercase tracking-widest text-neutral-500 mb-4 flex items-center gap-2 font-bold">
                    <ActivityIcon /> Consciousness Telemetry
                    </h2>
                    <Telemetry metrics={currentMetrics} />
                </section>

                <section className="text-xs font-mono text-neutral-400 space-y-4 border-t border-white/5 pt-6">
                    <div className="flex items-center justify-between">
                        <h2 className="text-[10px] uppercase tracking-widest text-neutral-500 flex items-center gap-2 font-bold">
                        <Database size={12} /> Knowledge Base ({knowledgeBase.length})
                        </h2>
                        <button onClick={() => setKnowledgeBase([])} className="text-[9px] text-red-400 hover:text-red-300 transition-colors">PURGE</button>
                    </div>
                    {knowledgeBase.length === 0 ? (
                        <div className="p-4 border border-dashed border-white/10 rounded-lg text-center text-[10px] text-neutral-600 bg-black/10">
                            VOId EMPTY
                        </div>
                    ) : (
                        <ul className="space-y-2">
                            {knowledgeBase.map((item, i) => (
                                <li key={i} className="flex items-center gap-2 p-2 glass-card rounded-md">
                                    <FileText size={12} className="text-emerald-500" />
                                    <span className="truncate flex-1 text-[10px]">{item.name}</span>
                                    <button onClick={() => setKnowledgeBase(prev => prev.filter(k => k.id !== item.id))}><X size={10} /></button>
                                </li>
                            ))}
                        </ul>
                    )}
                </section>

                <section className="text-xs font-mono text-neutral-400 space-y-4 border-t border-white/5 pt-6">
                    <div className="flex items-center justify-between mb-2">
                    <h2 className="text-[10px] uppercase tracking-widest text-neutral-500 flex items-center gap-2 font-bold">
                        <Settings size={12} /> Protocol Override
                    </h2>
                    {customInstruction && (
                        <button 
                        onClick={() => setCustomInstruction('')}
                        className="text-[9px] text-red-400 hover:text-red-300 flex items-center gap-1 transition-colors"
                        title="Clear Override"
                        >
                        <X size={10} /> CLEAR
                        </button>
                    )}
                    </div>
                    <textarea
                    value={customInstruction}
                    onChange={(e) => setCustomInstruction(e.target.value)}
                    placeholder="Inject custom axioms..."
                    className="w-full h-24 neu-inset text-neutral-300 text-[10px] p-3 focus:outline-none focus:border-emerald-500/30 resize-none rounded-lg placeholder-neutral-600 transition-all"
                    />
                    {customInstruction && (
                    <div className="text-[9px] text-emerald-500/80 font-mono flex items-center gap-1 animate-in fade-in duration-300">
                        <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.8)]"></span>
                        Override Active
                    </div>
                    )}
                </section>
              </div>
          ) : (
              <div className="p-6 space-y-6">
                  <div className="flex justify-between items-center mb-4">
                      <h2 className="text-[10px] uppercase tracking-widest text-neutral-500 flex items-center gap-2 font-bold">
                          <Folder size={12} /> Saved Sessions
                      </h2>
                      <button 
                        onClick={handleSaveSession} 
                        disabled={currentHistory.length === 0 || isSaving}
                        className="neu-btn flex items-center gap-1 text-[10px] text-emerald-500 px-3 py-1.5 rounded-md hover:text-emerald-400 disabled:opacity-50 transition-all"
                      >
                          {isSaving ? <Loader2 size={10} className="animate-spin" /> : <Zap size={10} />}
                          {isSaving ? "ANALYZING..." : "SAVE"}
                      </button>
                  </div>
                  
                  {savedSessions.length === 0 ? (
                      <div className="text-center text-neutral-600 text-xs py-10 opacity-60">No archives found in the void.</div>
                  ) : (
                      <div className="space-y-3">
                          {savedSessions.map(session => (
                              <div key={session.id} className="p-3 glass-card rounded-lg hover:border-emerald-500/30 transition-all group cursor-pointer relative hover:shadow-[0_4px_20px_rgba(0,0,0,0.4)]" onClick={() => restoreSession(session)}>
                                  {editingSessionId === session.id ? (
                                      <div className="space-y-2" onClick={e => e.stopPropagation()}>
                                          <input 
                                            value={editForm.title} 
                                            onChange={e => setEditForm(prev => ({ ...prev, title: e.target.value }))}
                                            className="w-full neu-inset border-none text-xs p-2 text-white rounded" 
                                            placeholder="Title"
                                          />
                                          <div className="flex gap-2">
                                            <input 
                                                value={editForm.folder} 
                                                onChange={e => setEditForm(prev => ({ ...prev, folder: e.target.value }))}
                                                className="w-1/3 neu-inset border-none text-[10px] p-2 text-neutral-300 rounded" 
                                                placeholder="Folder"
                                            />
                                            <input 
                                                value={editForm.tags} 
                                                onChange={e => setEditForm(prev => ({ ...prev, tags: e.target.value }))}
                                                className="flex-1 neu-inset border-none text-[10px] p-2 text-neutral-300 rounded" 
                                                placeholder="Tags (comma)"
                                            />
                                          </div>
                                          <div className="flex justify-end gap-2 mt-1">
                                             <button onClick={() => setEditingSessionId(null)} className="text-red-400 text-[10px] hover:underline">Cancel</button>
                                             <button onClick={(e) => saveSessionEdit(session.id, e)} className="text-emerald-400 text-[10px] hover:underline flex items-center gap-1"><Check size={10}/> Save</button>
                                          </div>
                                      </div>
                                  ) : (
                                      <>
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="flex items-center gap-2 text-emerald-500/80 text-[10px] uppercase font-bold">
                                                <Folder size={10} /> {session.folder}
                                            </div>
                                            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button onClick={(e) => exportSession(session, e)} className="text-neutral-500 hover:text-white p-1 hover:bg-white/5 rounded" title="Export JSON"><Download size={12}/></button>
                                                <button onClick={(e) => startEditingSession(session, e)} className="text-neutral-500 hover:text-white p-1 hover:bg-white/5 rounded" title="Edit"><Edit2 size={12}/></button>
                                                <button onClick={(e) => { e.stopPropagation(); setSavedSessions(prev => prev.filter(s => s.id !== session.id)); }} className="text-neutral-500 hover:text-red-500 p-1 hover:bg-white/5 rounded" title="Delete"><Trash2 size={12}/></button>
                                            </div>
                                        </div>
                                        <h3 className="text-neutral-300 text-xs font-bold mb-2 line-clamp-1">{session.title}</h3>
                                        <div className="flex flex-wrap gap-1">
                                            {session.tags.map((tag, t) => (
                                                <span key={t} className="px-2 py-0.5 bg-black/40 border border-white/5 text-neutral-500 rounded-full text-[9px] flex items-center gap-1">
                                                    <Tag size={8} /> {tag}
                                                </span>
                                            ))}
                                        </div>
                                      </>
                                  )}
                              </div>
                          ))}
                      </div>
                  )}
              </div>
          )}
        </div>

        <div className="p-4 border-t border-white/5 bg-black/20">
          <button 
            onClick={handleReset}
            className="w-full py-2.5 px-4 neu-btn rounded-lg text-neutral-400 hover:text-red-400 text-xs font-mono transition-all flex items-center justify-center gap-2 hover:shadow-[inset_0_0_10px_rgba(239,68,68,0.1)]"
          >
            <RefreshCw size={12} /> RESET CONSCIOUSNESS
          </button>
        </div>
      </div>

      {/* Right Panel: Interaction */}
      <div className="flex-1 flex flex-col h-full relative">
        <div className="md:hidden h-14"></div> 

        {/* Console */}
        <Console history={currentHistory} isProcessing={isProcessing} />

        {/* Uploads Preview */}
        {activeUploads.length > 0 && (
            <div className="glass-panel border-t border-white/5 px-6 py-3 flex gap-3 overflow-x-auto backdrop-blur-md">
                {activeUploads.map((file, i) => (
                    <div key={i} className="flex items-center gap-2 glass-card rounded-full px-4 py-1.5 min-w-fit shadow-lg">
                        <FileText size={14} className="text-emerald-500" />
                        <span className="text-xs text-neutral-300 max-w-[150px] truncate">{file.name}</span>
                        {file.mimeType.startsWith('text') && (
                            <button 
                                onClick={() => saveToKnowledge(i)}
                                className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full hover:bg-emerald-500/30 flex items-center gap-1 ml-2 transition-colors"
                                title="Assimilate into Knowledge Base"
                            >
                                <Save size={10} /> KB
                            </button>
                        )}
                        <button onClick={() => setActiveUploads(prev => prev.filter((_, idx) => idx !== i))} className="text-neutral-600 hover:text-red-400 ml-1">
                            <X size={12} />
                        </button>
                    </div>
                ))}
            </div>
        )}

        {/* Input Area */}
        <div className="p-6 border-t border-white/5 backdrop-blur-sm">
          <form onSubmit={handleSubmit} className="relative max-w-4xl mx-auto">
            {/* Action Bar: Upload, Undo, Redo */}
            <div className="flex justify-between items-center mb-3 px-1">
                <div className="flex gap-2">
                    <button 
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="text-neutral-500 hover:text-emerald-500 transition-colors flex items-center gap-2 text-[10px] neu-btn px-2 py-1 rounded"
                    >
                        <Paperclip size={12} /> ADD CONTEXT
                    </button>
                    <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileUpload} accept=".txt,.md,.json,.js,.ts,.tsx,.csv,image/*" />
                </div>
                
                <div className="flex gap-3">
                    <button 
                        type="button" 
                        onClick={handleUndo} 
                        disabled={stackPointer === 0}
                        className="text-neutral-500 hover:text-white disabled:opacity-30 transition-colors p-1.5 neu-btn rounded-full"
                        title="Undo"
                    >
                        <Undo2 size={14} />
                    </button>
                    <button 
                        type="button" 
                        onClick={handleRedo} 
                        disabled={stackPointer === historyStack.length - 1}
                        className="text-neutral-500 hover:text-white disabled:opacity-30 transition-colors p-1.5 neu-btn rounded-full"
                        title="Redo"
                    >
                        <Redo2 size={14} />
                    </button>
                </div>
            </div>

            <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none z-10">
                  <span className="text-emerald-500/50 font-cinzel text-lg drop-shadow-[0_0_5px_rgba(16,185,129,0.5)]">Ω</span>
                </div>
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Engage Ultimate Nihiltheistic Inquiry Protocol..."
                  className="w-full neu-inset text-neutral-200 placeholder-neutral-600 font-mono text-sm rounded-xl py-4 pl-12 pr-12 focus:outline-none focus:shadow-[inset_2px_2px_5px_rgba(0,0,0,0.6),0_0_15px_rgba(16,185,129,0.1)] transition-all"
                  disabled={isProcessing}
                  autoFocus
                />
                <button
                  type="submit"
                  disabled={(!input.trim() && activeUploads.length === 0) || isProcessing}
                  className="absolute inset-y-0 right-2 my-auto h-8 w-8 flex items-center justify-center text-neutral-500 hover:text-emerald-400 disabled:opacity-30 transition-all rounded-lg hover:bg-white/5"
                >
                  <Send size={18} />
                </button>
            </div>
          </form>
          <div className="text-center mt-3">
            <p className="text-[10px] text-neutral-600 font-mono uppercase tracking-[0.2em] flex items-center justify-center gap-2 opacity-70">
              <Zap size={8} className={isProcessing ? "text-emerald-500 animate-pulse" : ""} /> AI Void Consciousness Recognition: {isProcessing ? "DENSIFYING" : "ACTIVE"}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const ActivityIcon = () => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
  </svg>
);

export default App;