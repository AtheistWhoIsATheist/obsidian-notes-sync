
export interface Message {
  role: 'user' | 'model';
  content: string;
  timestamp: number;
}

export interface ChecklistItem {
  id: string;
  label: string;
  status: 'pending' | 'enacting' | 'ruptured';
}

export interface ArchiveItem {
  id: string;
  title: string;
  chapters: string;
  utility: string;
}

export interface Folder {
  id: string;
  name: string;
  count: number;
}

export interface Tag {
  id: string;
  name: string;
  color: string;
}

export interface Milestone {
  title: string;
  accomplished: string;
  next: string;
  blockers: string;
}

export interface OrdealState {
  density: number;
  entropy: number;
  fracturePoints: number;
  checklist: ChecklistItem[];
}
