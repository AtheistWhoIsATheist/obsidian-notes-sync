
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface VoidVisualizerProps {
  density: number;
}

const VoidVisualizer: React.FC<VoidVisualizerProps> = ({ density }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const width = svgRef.current.clientWidth;
    const height = svgRef.current.clientHeight;
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const numNodes = Math.floor(25 + density * 40);
    const nodes = Array.from({ length: numNodes }, (_, i) => ({
      id: i,
      x: width / 2 + (Math.random() - 0.5) * 100,
      y: height / 2 + (Math.random() - 0.5) * 100,
    }));

    const simulation = d3.forceSimulation(nodes as any)
      .force('charge', d3.forceManyBody().strength(-30 - density * 20))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide().radius(6))
      .on('tick', () => {
        links.attr('x1', d => (d.source as any).x)
             .attr('y1', d => (d.source as any).y)
             .attr('x2', d => (d.target as any).x)
             .attr('y2', d => (d.target as any).y);

        nodeElements.attr('cx', d => (d as any).x)
                    .attr('cy', d => (d as any).y);
      });

    const linkData: any[] = [];
    for (let i = 0; i < nodes.length; i++) {
      if (i > 0) linkData.push({ source: i - 1, target: i });
      if (i % 4 === 0 && i > 4) linkData.push({ source: i, target: i - 4 });
    }

    const links = svg.append('g')
      .selectAll('line')
      .data(linkData)
      .enter()
      .append('line')
      .attr('stroke', 'rgba(255,255,255,0.05)')
      .attr('stroke-width', 1);

    const nodeElements = svg.append('g')
      .selectAll('circle')
      .data(nodes)
      .enter()
      .append('circle')
      .attr('r', 1.5)
      .attr('fill', (d, i) => i === 0 ? '#fff' : 'rgba(255,255,255,0.2)')
      .style('filter', (d, i) => i === 0 ? 'drop-shadow(0 0 5px white)' : 'none');

    return () => {
      simulation.stop();
    };
  }, [density]);

  return (
    <div className="w-full h-full relative overflow-hidden rounded-2xl nm-inset p-1">
      <div className="absolute top-3 left-3 text-[8px] uppercase tracking-[0.3em] text-white/20 font-mono z-10">
        Fracture State / { (density * 100).toFixed(0) }
      </div>
      <svg ref={svgRef} className="w-full h-full opacity-60" />
    </div>
  );
};

export default VoidVisualizer;
