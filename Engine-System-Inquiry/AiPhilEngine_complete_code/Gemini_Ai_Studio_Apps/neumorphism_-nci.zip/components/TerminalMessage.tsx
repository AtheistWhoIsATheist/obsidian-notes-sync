
import React from 'react';
import { Message } from '../types';
import { marked } from 'marked';

interface TerminalMessageProps {
  message: Message;
}

const TerminalMessage: React.FC<TerminalMessageProps> = ({ message }) => {
  const isModel = message.role === 'model';
  
  // Configure marked for safe rendering
  const htmlContent = marked.parse(message.content || '...', {
    breaks: true,
    gfm: true,
  });

  return (
    <div className={`mb-24 flex ${isModel ? 'justify-start' : 'justify-end'} animate-in fade-in slide-in-from-bottom-8 duration-1000 ease-out`}>
      <div className={`max-w-[85%] nm-card p-10 md:p-12 relative transition-all hover:scale-[1.015] ${isModel ? 'border-l-8 border-white/5' : ''}`}>
        <div className="flex items-center gap-6 mb-10">
          <div className={`w-2.5 h-2.5 rounded-full ${isModel ? 'bg-white/10 animate-pulse' : 'bg-white/40'}`}></div>
          <span className={`text-[11px] font-bold uppercase tracking-[0.5em] ${isModel ? 'text-white/30' : 'text-white/60'}`}>
            {isModel ? 'OPERATOR_OUTPUT' : 'SUBJECT_CONTINUATION'}
          </span>
          <div className="h-[1px] flex-grow bg-white/5 mx-4"></div>
          <span className="text-[10px] text-white/10 font-mono tracking-widest opacity-40">
            {new Date(message.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </span>
        </div>
        
        <div className={`markdown-content leading-[1.7] tracking-wider ${isModel ? 'text-gray-100 font-serif-nihil font-light' : 'text-gray-300 font-mono text-[15px] opacity-75'}`}>
          <div 
            className={`selection:bg-white/20 selection:text-white drop-shadow-sm ${isModel ? 'italic text-[24px]' : ''}`}
            dangerouslySetInnerHTML={{ __html: htmlContent }}
          />
        </div>
        
        {isModel && (
          <div className="mt-12 flex gap-6 opacity-10">
            <div className="w-2 h-2 rounded-full bg-white animate-bounce [animation-delay:-0.3s]"></div>
            <div className="w-2 h-2 rounded-full bg-white animate-bounce [animation-delay:-0.15s]"></div>
            <div className="w-2 h-2 rounded-full bg-white animate-bounce"></div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TerminalMessage;
