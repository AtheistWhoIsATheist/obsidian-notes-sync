
import React from 'react';
import { ChecklistItem } from '../types';

interface OrdealChecklistProps {
  items: ChecklistItem[];
}

const OrdealChecklist: React.FC<OrdealChecklistProps> = ({ items }) => {
  if (items.length === 0) return null;

  return (
    <div className="mb-12 space-y-6">
      <div className="text-[11px] uppercase tracking-[0.5em] text-white/30 mb-6 px-4 font-bold">Current Ordeal</div>
      <div className="space-y-6">
        {items.map((item) => (
          <div key={item.id} className="flex items-center gap-6 p-5 nm-inset rounded-2xl transition-all duration-500 hover:nm-flat">
            <div className={`w-3 h-3 rounded-full shrink-0 transition-all duration-1000 ${
              item.status === 'ruptured' ? 'bg-white shadow-[0_0_15px_rgba(255,255,255,0.7)]' : 
              item.status === 'enacting' ? 'bg-white/50 animate-pulse scale-110' : 
              'bg-white/10'
            }`} />
            <span className={`text-[11px] uppercase tracking-[0.2em] leading-relaxed transition-colors duration-700 ${
              item.status === 'ruptured' ? 'text-white font-bold' : 
              item.status === 'enacting' ? 'text-white/70' : 
              'text-white/25'
            }`}>
              {item.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OrdealChecklist;
