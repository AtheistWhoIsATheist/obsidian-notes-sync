
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { NCI_SYSTEM_PROMPT } from "../constants";
import { Message } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;
  private model: string = 'gemini-3-pro-preview';

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async *streamNihil(history: Message[]) {
    // Re-initialize to ensure latest API key context
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const chat = ai.models.generateContentStream({
      model: this.model,
      contents: history.map(m => ({
        role: m.role,
        parts: [{ text: m.content }]
      })),
      config: {
        systemInstruction: NCI_SYSTEM_PROMPT,
        temperature: 0.85,
        topP: 0.9,
        thinkingConfig: { thinkingBudget: 0 } 
      }
    });

    for await (const chunk of chat) {
      yield chunk.text || '';
    }
  }

  async generateStaticNihil(history: Message[]): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: this.model,
      contents: history.map(m => ({
        role: m.role,
        parts: [{ text: m.content }]
      })),
      config: {
        systemInstruction: NCI_SYSTEM_PROMPT,
        temperature: 1,
      }
    });

    return response.text || "SILENCE.";
  }
}

export const geminiService = new GeminiService();
