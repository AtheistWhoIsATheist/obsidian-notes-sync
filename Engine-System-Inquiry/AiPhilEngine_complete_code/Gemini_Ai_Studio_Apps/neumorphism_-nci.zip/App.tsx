
import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { Message, ChecklistItem, ArchiveItem, Folder, Tag } from './types';
import { geminiService } from './services/geminiService';
import TerminalMessage from './components/TerminalMessage';
import VoidVisualizer from './components/VoidVisualizer';
import OrdealChecklist from './components/OrdealChecklist';

const INITIAL_VECTORS: ArchiveItem[] = [
  { id: 'v1', title: 'Heisman Ordeal', chapters: 'Ch. 173-177', utility: 'Self-Negation' },
  { id: 'v2', title: 'Kierkegaard Dread', chapters: 'Ch. 124-128', utility: 'Absurdity' },
  { id: 'v3', title: 'Rose Synthesis', chapters: 'Ch. 12-13', utility: 'Apophatics' },
  { id: 'v4', title: 'Leopardi Logic', chapters: 'Ch. 107, 165', utility: 'Disenchantment' },
  { id: 'v5', title: 'Eckhart\'s Void', chapters: 'Ch. 71-73', utility: 'Annihilation' }
];

const INITIAL_FOLDERS: Folder[] = [
  { id: 'f1', name: 'Primary Ordeals', count: 12 },
  { id: 'f2', name: 'Recursive Archives', count: 45 },
  { id: 'f3', name: 'Subjective Nullity', count: 8 }
];

const INITIAL_TAGS: Tag[] = [
  { id: 't1', name: 'void', color: '#888' },
  { id: 't2', name: 'rupture', color: '#fff' },
  { id: 't3', name: 'J314', color: '#666' }
];

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [density, setDensity] = useState(0.25);
  const [checklist, setChecklist] = useState<ChecklistItem[]>([]);
  const [activeFolder, setActiveFolder] = useState('f1');
  
  // Sidebar Toggle State
  const [isLeftSidebarOpen, setIsLeftSidebarOpen] = useState(true);
  const [isRightSidebarOpen, setIsRightSidebarOpen] = useState(true);

  // Dynamic Organization State
  const [folders, setFolders] = useState<Folder[]>(INITIAL_FOLDERS);
  const [tags, setTags] = useState<Tag[]>(INITIAL_TAGS);
  const [newFolderName, setNewFolderName] = useState('');
  const [newTagName, setNewTagName] = useState('');
  const [showAddFolder, setShowAddFolder] = useState(false);
  const [showAddTag, setShowAddTag] = useState(false);

  // Derived State
  const totalNotesCount = useMemo(() => folders.reduce((acc, f) => acc + f.count, 0), [folders]);

  // Drag and Drop State
  const [draggedItemIndex, setDraggedItemIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = useCallback(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  const parseResponse = (text: string) => {
    const lines = text.split('\n');
    const newItems: ChecklistItem[] = [];
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.startsWith('*') || trimmed.startsWith('-')) {
        const label = trimmed.replace(/^[\*\-]\s*/, '').trim();
        if (label.length > 0 && label.length < 100) {
          newItems.push({ id: Math.random().toString(36), label, status: 'enacting' });
        }
      } else if (trimmed.length > 0 && !trimmed.startsWith('#')) break;
      if (newItems.length >= 7) break;
    }
    return newItems;
  };

  const handleAddFolder = () => {
    if (newFolderName.trim()) {
      const newFolder: Folder = {
        id: Math.random().toString(36).substr(2, 9),
        name: newFolderName.trim(),
        count: 0
      };
      setFolders([...folders, newFolder]);
      setNewFolderName('');
      setShowAddFolder(false);
    }
  };

  const handleRemoveFolder = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFolders(folders.filter(f => f.id !== id));
    if (activeFolder === id) {
      setActiveFolder(folders[0]?.id || '');
    }
  };

  const updateFolderCount = (id: string, delta: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setFolders(prev => prev.map(f => 
      f.id === id ? { ...f, count: Math.max(0, f.count + delta) } : f
    ));
  };

  const handleAddTag = () => {
    if (newTagName.trim()) {
      const newTag: Tag = {
        id: Math.random().toString(36).substr(2, 9),
        name: newTagName.trim().toLowerCase(),
        color: '#888'
      };
      setTags([...tags, newTag]);
      setNewTagName('');
      setShowAddTag(false);
    }
  };

  const handleRemoveTag = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setTags(tags.filter(t => t.id !== id));
  };

  // Drag and Drop Logic
  const onDragStart = (e: React.DragEvent, index: number) => {
    setDraggedItemIndex(index);
    e.dataTransfer.effectAllowed = 'move';
    const target = e.currentTarget as HTMLElement;
    target.style.opacity = '0.4';
  };

  const onDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    setDragOverIndex(index);
  };

  const onDragEnd = (e: React.DragEvent) => {
    const target = e.currentTarget as HTMLElement;
    target.style.opacity = '1';
    setDraggedItemIndex(null);
    setDragOverIndex(null);
  };

  const onDrop = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedItemIndex === null) return;
    
    const updatedFolders = [...folders];
    const draggedItem = updatedFolders[draggedItemIndex];
    updatedFolders.splice(draggedItemIndex, 1);
    updatedFolders.splice(index, 0, draggedItem);
    
    setFolders(updatedFolders);
    setDraggedItemIndex(null);
    setDragOverIndex(null);
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isProcessing) return;

    const userMsg: Message = { role: 'user', content: input, timestamp: Date.now() };
    setInput('');
    setMessages(prev => [...prev, userMsg]);
    setIsProcessing(true);
    setDensity(prev => Math.min(1, prev + 0.1));
    
    // Automatically increment active folder count on new entry
    updateFolderCount(activeFolder, 1);

    try {
      const history = [...messages, userMsg];
      let fullResponse = '';
      const modelPlaceholder: Message = { role: 'model', content: '', timestamp: Date.now() };
      setMessages(prev => [...prev, modelPlaceholder]);

      const stream = geminiService.streamNihil(history);
      let parsedInitialChecklist = false;
      
      for await (const chunk of stream) {
        fullResponse += chunk;
        if (!parsedInitialChecklist && fullResponse.length > 100) {
          const items = parseResponse(fullResponse);
          if (items.length > 0) {
            setChecklist(items);
            parsedInitialChecklist = true;
          }
        }
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1].content = fullResponse;
          return newMessages;
        });
        scrollToBottom();
      }
      setChecklist(prev => prev.map(item => ({ ...item, status: 'ruptured' })));
    } catch (error) {
      setMessages(prev => [...prev, {
        role: 'model',
        content: "Continuity collapsed. Re-index.",
        timestamp: Date.now()
      }]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="flex h-screen w-full bg-[#222222] text-gray-300 font-mono overflow-hidden relative">
      
      {/* LEFT SIDEBAR: Organization Panel */}
      <aside 
        className={`transition-all duration-500 ease-in-out h-full bg-[#222222] border-r border-white/5 z-20 flex flex-col overflow-hidden ${isLeftSidebarOpen ? 'w-80 p-8' : 'w-0 p-0 overflow-hidden border-none'}`}
      >
        <div className="min-w-[260px] flex flex-col gap-10">
          <div className="nm-card p-6 text-center shrink-0">
            <h1 className="text-white text-[13px] font-bold tracking-[0.6em] uppercase mb-1">2ND BRAIN</h1>
            <p className="text-[10px] text-white/20 uppercase tracking-[0.3em]">J314 Operator Core</p>
          </div>

          <section className="space-y-6 shrink-0">
            <div className="flex flex-col gap-4">
              <div className="nm-inset py-4 px-6 rounded-2xl flex flex-col items-center justify-center border border-white/5">
                <span className="text-[9px] uppercase tracking-[0.4em] text-white/20 mb-1">Total Notes</span>
                <span className="text-xl font-bold text-white tracking-tighter">{totalNotesCount}</span>
              </div>
              
              <div className="flex items-center justify-between px-2 mt-4">
                <span className="text-[10px] uppercase tracking-[0.4em] text-white/40">Folders</span>
                <button 
                  onClick={() => setShowAddFolder(!showAddFolder)}
                  className="nm-button w-8 h-8 text-white/30 hover:text-white"
                >+</button>
              </div>
            </div>
            
            {showAddFolder && (
              <div className="px-2 animate-in fade-in slide-in-from-top-2">
                <input 
                  autoFocus
                  type="text"
                  placeholder="Folder Name..."
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddFolder()}
                  className="w-full bg-transparent nm-inset p-3 rounded-xl text-[10px] focus:outline-none placeholder:text-white/10 text-white"
                />
              </div>
            )}

            <div className="space-y-4 px-1 max-h-[300px] overflow-y-auto no-scrollbar pb-4">
              {folders.map((f, index) => (
                <div 
                  key={f.id} 
                  onClick={() => setActiveFolder(f.id)}
                  onDragStart={(e) => onDragStart(e, index)}
                  onDragOver={(e) => onDragOver(e, index)}
                  onDragEnd={onDragEnd}
                  onDrop={(e) => onDrop(e, index)}
                  draggable
                  className={`flex justify-between items-center p-4 nm-button group cursor-grab active:cursor-grabbing transition-all duration-300 ${activeFolder === f.id ? 'active' : ''} ${dragOverIndex === index ? 'border-b-2 border-white/20 scale-[1.02]' : ''}`}
                >
                  <div className="flex items-center gap-3">
                    <span className={`text-[11px] uppercase tracking-widest ${activeFolder === f.id ? 'text-white font-bold' : 'text-white/40 group-hover:text-white/70'}`}>
                      {f.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={(e) => updateFolderCount(f.id, -1, e)}
                        className="w-5 h-5 flex items-center justify-center nm-inset text-[10px] rounded-md text-white/30 hover:text-white"
                      >-</button>
                      <button 
                        onClick={(e) => updateFolderCount(f.id, 1, e)}
                        className="w-5 h-5 flex items-center justify-center nm-inset text-[10px] rounded-md text-white/30 hover:text-white"
                      >+</button>
                    </div>
                    <span className="text-[9px] opacity-30 font-bold nm-inset px-2 py-0.5 rounded-md min-w-[24px] text-center">{f.count}</span>
                    <button 
                      onClick={(e) => handleRemoveFolder(f.id, e)}
                      className="opacity-0 group-hover:opacity-40 hover:opacity-100 text-[10px] text-red-400"
                    >×</button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="space-y-6 shrink-0">
            <div className="flex items-center justify-between px-2">
              <span className="text-[10px] uppercase tracking-[0.4em] text-white/40">Continuity Tags</span>
              <button 
                onClick={() => setShowAddTag(!showAddTag)}
                className="nm-button w-8 h-8 text-white/30 hover:text-white"
              >+</button>
            </div>

            {showAddTag && (
              <div className="px-2 animate-in fade-in slide-in-from-top-2">
                <input 
                  autoFocus
                  type="text"
                  placeholder="New Tag..."
                  value={newTagName}
                  onChange={(e) => setNewTagName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddTag()}
                  className="w-full bg-transparent nm-inset p-3 rounded-xl text-[10px] focus:outline-none text-white"
                />
              </div>
            )}

            <div className="flex flex-wrap gap-4 px-2">
              {tags.map(t => (
                <div key={t.id} className="nm-button px-4 py-2 text-[10px] uppercase tracking-widest text-white/40 hover:text-white/80 cursor-pointer group flex gap-3 items-center">
                  #{t.name}
                  <button onClick={(e) => handleRemoveTag(t.id, e)} className="opacity-0 group-hover:opacity-100 text-red-500/50">×</button>
                </div>
              ))}
            </div>
          </section>

          <section className="pt-8 border-t border-white/5 mt-auto">
            <div className="nm-inset p-6 rounded-[32px] space-y-5">
              <div className="flex justify-between items-center text-[10px] text-white/20 uppercase tracking-[0.3em]">
                <span>Ordeal Depth</span>
                <span>{(density * 100).toFixed(0)}%</span>
              </div>
              <div className="h-[4px] w-full bg-black/40 rounded-full overflow-hidden p-[1px]">
                <div 
                  className="h-full bg-gradient-to-r from-gray-700 to-white transition-all duration-1000 shadow-[0_0_15px_rgba(255,255,255,0.3)]" 
                  style={{ width: `${density * 100}%` }}
                ></div>
              </div>
            </div>
          </section>
        </div>
      </aside>

      {/* MAIN CONTENT: Central Field */}
      <main className="flex-grow flex flex-col relative bg-[#222222] min-w-0">
        {/* Unified Header with Toggles */}
        <header className="p-8 flex justify-between items-center nm-flat border-b border-white/5 z-10 shrink-0">
          <div className="flex items-center gap-6">
            {/* Left Toggle Switch */}
            <button 
              onClick={() => setIsLeftSidebarOpen(!isLeftSidebarOpen)}
              className={`nm-button w-12 h-8 relative transition-colors duration-300 ${isLeftSidebarOpen ? 'bg-white/5' : 'nm-inset'}`}
              title="Toggle Organization Brain"
            >
              <div className={`absolute w-4 h-4 rounded-full transition-all duration-300 ${isLeftSidebarOpen ? 'bg-white right-2' : 'bg-white/20 left-2'}`}></div>
            </button>
            
            <div className="flex flex-col ml-2">
              <span className="text-[12px] uppercase tracking-[0.5em] text-white/70 font-bold">ALPHA CONTINUITY STREAM</span>
              <span className="text-[9px] text-white/20 uppercase tracking-[0.2em] mt-1">Status: Active Rupture</span>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden md:flex gap-4">
              <button className="nm-button px-6 py-3 text-[10px] text-white/40 font-bold tracking-widest hover:text-white">SAVE ARCHIVE</button>
            </div>

            {/* Right Toggle Switch */}
            <button 
              onClick={() => setIsRightSidebarOpen(!isRightSidebarOpen)}
              className={`nm-button w-12 h-8 relative transition-colors duration-300 ${isRightSidebarOpen ? 'bg-white/5' : 'nm-inset'}`}
              title="Toggle Diagnostics"
            >
              <div className={`absolute w-4 h-4 rounded-full transition-all duration-300 ${isRightSidebarOpen ? 'bg-white left-2' : 'bg-white/20 right-2'}`}></div>
            </button>
          </div>
        </header>

        {/* Messages List */}
        <div 
          ref={scrollRef}
          className="flex-grow overflow-y-auto p-12 md:p-16 lg:px-24 xl:px-32 space-y-16 no-scrollbar"
        >
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center pointer-events-none opacity-40 group">
              <div className="text-[90px] font-serif-nihil italic text-white/5 mb-10 select-none transition-all group-hover:scale-105 duration-1000">Void.</div>
              <div className="text-[11px] uppercase tracking-[2em] text-white/10 animate-pulse text-center">
                Initiate Rational Fracture<br/>
                <span className="text-[8px] tracking-[0.5em] mt-4 block">[ J314: 197 Chapters Indexed ]</span>
              </div>
            </div>
          ) : (
            <div className="max-w-5xl mx-auto pb-64">
              {messages.map((m, idx) => (
                <TerminalMessage key={idx} message={m} />
              ))}
              {isProcessing && (
                <div className="flex items-center gap-6 mt-12 opacity-40">
                  <div className="h-[2px] w-20 bg-gradient-to-r from-transparent to-white animate-pulse"></div>
                  <div className="text-[11px] uppercase tracking-[0.7em] text-white/60 italic font-thin">Descanting Recursion...</div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Floating Input Component */}
        <div className="absolute bottom-0 left-0 right-0 p-12 pointer-events-none z-30">
          <div className="max-w-5xl mx-auto pointer-events-auto">
            <div className="nm-card p-8 flex flex-col gap-8 bg-[#222222]/98 backdrop-blur-3xl border border-white/5 shadow-2xl">
              <textarea
                ref={inputRef}
                rows={1}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={isProcessing}
                placeholder="CONVEY A FRACTURE..."
                className="w-full bg-transparent border-none py-6 px-10 focus:outline-none transition-colors resize-none placeholder:text-white/5 uppercase tracking-[0.3em] text-[15px] text-white/90 nm-inset rounded-[28px]"
              />
              <div className="flex justify-between items-center px-6">
                <div className="hidden sm:flex gap-6 opacity-30">
                  <span className="text-[10px] uppercase tracking-[0.2em] bg-black/30 px-4 py-2 rounded-xl">Alt + Enter: Fork</span>
                  <span className="text-[10px] uppercase tracking-[0.2em] bg-black/30 px-4 py-2 rounded-xl">Shift: Depth</span>
                </div>
                <button 
                  onClick={() => handleSubmit()}
                  disabled={isProcessing || !input.trim()}
                  className="nm-button px-16 py-5 text-[12px] font-bold uppercase tracking-[1em] text-white/50 hover:text-white transition-all shadow-2xl ml-auto"
                >
                  ENACT
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* RIGHT SIDEBAR: Diagnostics / Checklist */}
      <aside 
        className={`transition-all duration-500 ease-in-out h-full bg-[#222222] border-l border-white/5 z-20 flex flex-col overflow-hidden ${isRightSidebarOpen ? 'w-80 p-10' : 'w-0 p-0 overflow-hidden border-none'}`}
      >
        <div className="min-w-[260px] flex flex-col h-full overflow-y-auto no-scrollbar gap-16">
          <div className="h-52 shrink-0">
            <VoidVisualizer density={density} />
          </div>

          <div className="space-y-16">
            <OrdealChecklist items={checklist} />

            <section className="space-y-10">
              <div className="border-t border-white/5 pt-10 px-2">
                <div className="text-[11px] uppercase tracking-[0.5em] text-white/30 mb-8 font-bold">Ontological Anchors</div>
                <div className="space-y-6">
                  {INITIAL_VECTORS.map(v => (
                    <div key={v.id} className="nm-inset p-6 rounded-[28px] group transition-all hover:nm-card cursor-help">
                      <div className="text-[12px] text-white/60 uppercase tracking-widest font-bold mb-2">{v.title}</div>
                      <div className="flex justify-between text-[10px] text-white/20 uppercase tracking-tight">
                        <span>{v.chapters}</span>
                        <span className="italic">{v.utility}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </div>

          <div className="pt-10 text-[10px] border-t border-white/5 opacity-20 uppercase tracking-[0.4em] leading-loose text-center italic mt-auto shrink-0 pb-8">
            "Language is Rupture" (Ch. 49)
          </div>
        </div>
      </aside>
    </div>
  );
};

export default App;
